// Deploys FalcoCard, then FalcoMarket pointed at it.
// Usage:  npx hardhat run scripts/deploy.js --network sepolia
const hre = require("hardhat");

async function main() {
  const FalcoCard = await hre.ethers.getContractFactory("FalcoCard");
  const falcoCard = await FalcoCard.deploy();
  await falcoCard.waitForDeployment();
  const cardAddress = await falcoCard.getAddress();
  console.log("FalcoCard deployed at:", cardAddress);

  const FalcoMarket = await hre.ethers.getContractFactory("FalcoMarket");
  const falcoMarket = await FalcoMarket.deploy(cardAddress);
  await falcoMarket.waitForDeployment();
  console.log("FalcoMarket deployed at:", await falcoMarket.getAddress());

  console.log("\nSave these two addresses — you'll paste them into web/config.js");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
