const CARD_READ_ABI = [
  "function ownerOf(uint256) view returns (address)",
  "function power(uint256) view returns (uint16)",
  "function deckType(uint256) view returns (string)",
  "function tokenURI(uint256) view returns (string)",
];

async function readCard(provider, tokenId) {
  const contract = new ethers.Contract(FALCO_CONFIG.CARD_ADDRESS, CARD_READ_ABI, provider);
  const [owner, power, deckType, tokenURI] = await Promise.all([
    contract.ownerOf(tokenId),
    contract.power(tokenId),
    contract.deckType(tokenId),
    contract.tokenURI(tokenId),
  ]);
  return { tokenId, owner, power, deckType, tokenURI };
}
