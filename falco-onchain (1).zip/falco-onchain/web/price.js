// No API key needed. Rate-limited on CoinGecko's free tier — cache the result
// client-side for at least 30-60 seconds if you poll this.
async function getEthUsdPrice() {
  const res = await fetch(
    "https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd"
  );
  if (!res.ok) throw new Error("price fetch failed: " + res.status);
  const data = await res.json();
  return data.ethereum.usd;
}
