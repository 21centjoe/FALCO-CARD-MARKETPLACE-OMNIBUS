const CARD_APPROVE_ABI = [
  "function setApprovalForAll(address operator, bool approved)",
];
const MARKET_ABI = [
  "function list(uint256 tokenId, uint256 priceWei)",
  "function cancel(uint256 tokenId)",
  "function buy(uint256 tokenId) payable",
  "function listings(uint256) view returns (address seller, uint256 price, bool active)",
];

// One-time approval so the market contract is allowed to move your cards on a sale.
async function approveMarket(signer) {
  const card = new ethers.Contract(FALCO_CONFIG.CARD_ADDRESS, CARD_APPROVE_ABI, signer);
  const tx = await card.setApprovalForAll(FALCO_CONFIG.MARKET_ADDRESS, true);
  await tx.wait();
}

async function listCard(signer, tokenId, priceEth) {
  const market = new ethers.Contract(FALCO_CONFIG.MARKET_ADDRESS, MARKET_ABI, signer);
  const priceWei = ethers.parseEther(String(priceEth));
  const tx = await market.list(tokenId, priceWei);
  return tx.wait();
}

async function cancelListing(signer, tokenId) {
  const market = new ethers.Contract(FALCO_CONFIG.MARKET_ADDRESS, MARKET_ABI, signer);
  const tx = await market.cancel(tokenId);
  return tx.wait();
}

async function buyCard(signer, tokenId) {
  const market = new ethers.Contract(FALCO_CONFIG.MARKET_ADDRESS, MARKET_ABI, signer);
  const listing = await market.listings(tokenId);
  if (!listing.active) throw new Error("Listing is not active.");
  const tx = await market.buy(tokenId, { value: listing.price });
  return tx.wait();
}
