// Mints one card. Only the contract owner's wallet can call this
// (see the `onlyOwner` modifier on FalcoCard.mint) — typically your
// own backend/admin key, not an arbitrary player's wallet.
const CARD_ABI = [
  "function mint(address to, string tokenURI_, uint16 power_, string deckType_) returns (uint256)",
];

async function mintCard(signer, toAddress, tokenURI, power, deckType) {
  const contract = new ethers.Contract(FALCO_CONFIG.CARD_ADDRESS, CARD_ABI, signer);
  const tx = await contract.mint(toAddress, tokenURI, power, deckType);
  const receipt = await tx.wait();
  return receipt;
}

// Example metadata JSON to host (IPFS, or your own server) and pass as tokenURI:
//
// {
//   "name": "Il Bagatto — the Router",
//   "description": "Key I of the FALCO arcana.",
//   "image": "https://your-host.example/il-bagatto.png",
//   "attributes": [
//     { "trait_type": "Power", "value": 62 },
//     { "trait_type": "Deck", "value": "falco" }
//   ]
// }
