// Fill in after running scripts/deploy.js
const FALCO_CONFIG = {
  CARD_ADDRESS: "0xPASTE_FALCOCARD_ADDRESS_HERE",
  MARKET_ADDRESS: "0xPASTE_FALCOMARKET_ADDRESS_HERE",
  CHAIN_ID_HEX: "0xaa36a7", // Sepolia testnet. Mainnet is 0x1 — do not point real funds here without an audit.
};
