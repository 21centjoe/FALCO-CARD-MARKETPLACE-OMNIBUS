// Requires ethers.js loaded first, e.g.:
// <script src="https://cdnjs.cloudflare.com/ajax/libs/ethers/6.13.1/ethers.umd.min.js"></script>

async function connectWallet() {
  if (!window.ethereum) {
    alert("Install MetaMask (or another injected wallet) to continue.");
    return null;
  }
  const provider = new ethers.BrowserProvider(window.ethereum);
  await provider.send("eth_requestAccounts", []);

  // make sure we're on the expected network
  const network = await provider.getNetwork();
  if ("0x" + network.chainId.toString(16) !== FALCO_CONFIG.CHAIN_ID_HEX) {
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: FALCO_CONFIG.CHAIN_ID_HEX }],
      });
    } catch (err) {
      alert("Please switch your wallet to the expected network and try again.");
      return null;
    }
  }

  const signer = await provider.getSigner();
  const address = await signer.getAddress();
  const el = document.getElementById("walletAddr");
  if (el) el.textContent = address;
  return { provider, signer, address };
}
