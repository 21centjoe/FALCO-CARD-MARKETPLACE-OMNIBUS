// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";

/// @title FalcoMarket
/// @notice A minimal peer-to-peer marketplace for FalcoCard tokens, priced in the chain's native currency.
/// @dev Unaudited scaffolding. Get a real audit before listing anything with real value.
contract FalcoMarket is ReentrancyGuard {
    IERC721 public immutable cards;

    struct Listing {
        address seller;
        uint256 price; // in wei
        bool active;
    }

    mapping(uint256 => Listing) public listings;

    event Listed(uint256 indexed tokenId, address indexed seller, uint256 price);
    event Sold(uint256 indexed tokenId, address indexed buyer, uint256 price);
    event Cancelled(uint256 indexed tokenId);

    constructor(address cardsAddress) {
        cards = IERC721(cardsAddress);
    }

    /// @notice List a card you own. You must first call
    ///   cards.setApprovalForAll(marketAddress, true)
    /// from your wallet so this contract can move the token on a sale.
    function list(uint256 tokenId, uint256 priceWei) external {
        require(cards.ownerOf(tokenId) == msg.sender, "not owner");
        require(cards.isApprovedForAll(msg.sender, address(this)), "approve market first");
        require(priceWei > 0, "price must be > 0");
        listings[tokenId] = Listing(msg.sender, priceWei, true);
        emit Listed(tokenId, msg.sender, priceWei);
    }

    function cancel(uint256 tokenId) external {
        Listing memory l = listings[tokenId];
        require(l.active, "not listed");
        require(l.seller == msg.sender, "not your listing");
        listings[tokenId].active = false;
        emit Cancelled(tokenId);
    }

    function buy(uint256 tokenId) external payable nonReentrant {
        Listing memory l = listings[tokenId];
        require(l.active, "not listed");
        require(msg.value >= l.price, "underpaid");

        listings[tokenId].active = false;
        cards.safeTransferFrom(l.seller, msg.sender, tokenId);

        (bool sent, ) = payable(l.seller).call{value: l.price}("");
        require(sent, "payment to seller failed");

        // refund any overpayment
        if (msg.value > l.price) {
            (bool refunded, ) = payable(msg.sender).call{value: msg.value - l.price}("");
            require(refunded, "refund failed");
        }

        emit Sold(tokenId, msg.sender, l.price);
    }
}
