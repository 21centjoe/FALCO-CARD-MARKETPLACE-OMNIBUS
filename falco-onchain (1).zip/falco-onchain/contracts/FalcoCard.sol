// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/// @title FalcoCard
/// @notice A minimal ERC-721 representing one FALCO / Euchre / Naipes / Tarot card.
/// @dev Test on a testnet (e.g. Sepolia) before ever deploying with real funds involved.
contract FalcoCard is ERC721URIStorage, Ownable {
    uint256 public nextId;

    // on-chain stats, mirroring the fields used in the FALCO Vault page
    mapping(uint256 => uint16) public power;      // 1-99
    mapping(uint256 => string) public deckType;   // "falco" | "euchre" | "naipes" | "tarot" | "custom"

    event CardMinted(uint256 indexed tokenId, address indexed to, string deckType, uint16 power);

    constructor() ERC721("FALCO Card", "FALCO") Ownable(msg.sender) {}

    /// @param to           recipient wallet address
    /// @param tokenURI_    URL or data-URI for the card's metadata JSON (name/image/attributes)
    /// @param power_       the card's power stat
    /// @param deckType_    which deck this card belongs to
    function mint(
        address to,
        string memory tokenURI_,
        uint16 power_,
        string memory deckType_
    ) external onlyOwner returns (uint256) {
        uint256 id = nextId++;
        _safeMint(to, id);
        _setTokenURI(id, tokenURI_);
        power[id] = power_;
        deckType[id] = deckType_;
        emit CardMinted(id, to, deckType_, power_);
        return id;
    }

    /// @notice Let the card's owner raise its power stat (mirrors the Vault's "Train" feature).
    /// @dev Add access control / a cooldown / a payment requirement here before using this for real.
    function train(uint256 tokenId, uint16 amount) external {
        require(ownerOf(tokenId) == msg.sender, "not your card");
        require(power[tokenId] + amount <= 99, "power capped at 99");
        power[tokenId] += amount;
    }
}
